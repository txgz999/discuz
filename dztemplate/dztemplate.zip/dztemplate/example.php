<?php

require_once ('source/function/function_core.php');

$testArr = array('testa' => 'a', 'testb' => 'b');
include template('demo');

?>