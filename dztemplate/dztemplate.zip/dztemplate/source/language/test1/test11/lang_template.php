<?php

$lang = array (
    'last_1_days' => '一天',
);

?>