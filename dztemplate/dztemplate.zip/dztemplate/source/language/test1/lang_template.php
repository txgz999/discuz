<?php

$lang = array (
  'last_2_days' => '两天',
  'list_one_month' => '一个月',
  'activity_jointime' => '申请时间',
  'activity_member_unit' => '报名申请人',
);

?>