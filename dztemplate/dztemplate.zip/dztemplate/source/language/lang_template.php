<?php

$lang = array (
  'list_one_month' => '一个月',
  'world' => '世界',
  'activity_about_member' => '剩余名额',
  'activity_already' => '已参加人数',
  'attach_forward' => '如果 {$refreshsecond} 秒后下载仍未开始，请点击此链接',
);

?>