<?php

class template {

	var $depfiles = array(); //依赖文件文件列表
    var $replacecode = array('search' => array(), 'replace' => array());
    var $language = array();
	var $file = '';

	function parse_template($tplfile, $file, $cachefile) {
		$this->file = $file;

        //取得模板内容
		if($fp = @fopen(DISCUZ_ROOT.$tplfile, 'r')) {
			$template = @fread($fp, filesize(DISCUZ_ROOT.$tplfile));
			fclose($fp);
		} elseif($fp = @fopen($filename = substr(DISCUZ_ROOT.$tplfile, 0, -4).'.php', 'r')) {
			$template = $this->getphptemplate(@fread($fp, filesize($filename)));
			fclose($fp);
		} else {
			$this->error('template_notfound', $tplfile);
		}

		$var_regexp = "((\\\$[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*(\-\>)?[a-zA-Z0-9_\x7f-\xff]*)(\[[a-zA-Z0-9_\-\.\"\'\[\]\$\x7f-\xff]+\])*)";
		$const_regexp = "([a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*)";

		$this->depfiles = array();
		for($i = 1; $i <= 10; $i++) {
			while(strexists($template, '{subtemplate')) {
				$template = preg_replace_callback("/[\n\r\t]*(\<\!\-\-)?\{subtemplate\s+([a-z0-9_\.\/]+)\}(\-\-\>)?[\n\r\t]*/is", array($this, 'parse_template_callback_loadsubtemplate_2'), $template);
			}
		}

		$template = preg_replace_callback("/[\n\r\t]*\{css\s+(.+?)\}[\n\r\t]*/is", array($this, 'parse_template_callback_csstags_1'), $template);
		$template = preg_replace_callback("/[\n\r\t]*\{js\s+(.+?)\}[\n\r\t]*/is", array($this, 'parse_template_callback_jstags_1'), $template);

		$template = preg_replace("/([\n\r]+)\t+/s", "\\1", $template);

        //过滤 <!--{}-->
        $template = preg_replace("/\<\!\-\-\{(.+?)\}\-\-\>/s", "{\\1}", $template);

        //语言包
        $template = preg_replace_callback("/\{lang\s+(.+?)\}/is", array($this, 'parse_template_callback_languagevar_1'), $template);

        //替换特定函数
        $template = preg_replace_callback("/[\n\r\t]*\{eval\}\s*(\<\!\-\-)*(.+?)(\-\-\>)*\s*\{\/eval\}[\n\r\t]*/is", array($this, 'parse_template_callback_evaltags_2'), $template);
		$template = preg_replace_callback("/[\n\r\t]*\{eval\s+(.+?)\s*\}[\n\r\t]*/is", array($this, 'parse_template_callback_evaltags_1'), $template);

        //替换 PHP 换行符
        $template = str_replace("{LF}", "<?=\"\\n\"?>", $template);
		$template = preg_replace("/\{(\\\$[a-zA-Z0-9_\-\>\[\]\'\"\$\.\x7f-\xff]+)\}/s", "<?=\\1?>", $template);

        //替换直接变量输出
        $template = preg_replace_callback("/$var_regexp/s", array($this, 'parse_template_callback_addquote_1'), $template);
		$template = preg_replace_callback("/\<\?\=\<\?\=$var_regexp\?\>\?\>/s", array($this, 'parse_template_callback_addquote_1'), $template);

		$headeradd = '';
		if(!empty($this->depfiles)) {
			$headeradd .= "\n0\n";
			foreach($this->depfiles as $fname) {
				$headeradd .= "|| checktplrefresh('$tplfile', '$fname', ".time().", '$cachefile', '$file')\n";
			}
			$headeradd .= ';';
		}

		$template = "<? {$headeradd}?>\n$template";

        //替换模板载入命令
		$template = preg_replace_callback("/[\n\r\t]*\{template\s+([a-z0-9_:\/]+)\}[\n\r\t]*/is", array($this, 'parse_template_callback_stripvtags_template1'), $template);
		$template = preg_replace_callback("/[\n\r\t]*\{template\s+(.+?)\}[\n\r\t]*/is", array($this, 'parse_template_callback_stripvtags_template1'), $template);

        //替换特定函数
        $template = preg_replace_callback("/[\n\r\t]*\{echo\s+(.+?)\}[\n\r\t]*/is", array($this, 'parse_template_callback_stripvtags_echo1'), $template);

        //替换条件判断语句
		$template = preg_replace_callback("/([\n\r\t]*)\{if\s+(.+?)\}([\n\r\t]*)/is", array($this, 'parse_template_callback_stripvtags_if123'), $template);
		$template = preg_replace_callback("/([\n\r\t]*)\{elseif\s+(.+?)\}([\n\r\t]*)/is", array($this, 'parse_template_callback_stripvtags_elseif123'), $template);
		$template = preg_replace("/\{else\}/i", "<? } else { ?>", $template);
		$template = preg_replace("/\{\/if\}/i", "<? } ?>", $template);

        //替换循环函数
		$template = preg_replace_callback("/[\n\r\t]*\{loop\s+(\S+)\s+(\S+)\}[\n\r\t]*/is", array($this, 'parse_template_callback_stripvtags_loop12'), $template);
		$template = preg_replace_callback("/[\n\r\t]*\{loop\s+(\S+)\s+(\S+)\s+(\S+)\}[\n\r\t]*/is", array($this, 'parse_template_callback_stripvtags_loop123'), $template);
		$template = preg_replace("/\{\/loop\}/i", "<? } ?>", $template);

		$template = preg_replace("/\{$const_regexp\}/s", "<?=\\1?>", $template);
		if(!empty($this->replacecode)) {
			$template = str_replace($this->replacecode['search'], $this->replacecode['replace'], $template);
		}

        //删除 PHP 代码断间多余的空格及换行
		$template = preg_replace("/ \?\>[\n\r]*\<\? /s", " ", $template);

		$template = preg_replace_callback("/\"(http)?[\w\.\/:]+\?[^\"]+?&[^\"]+?\"/", array($this, 'parse_template_callback_transamp_0'), $template);

        $template = preg_replace_callback("/[\n\r\t]*\{block\s+([a-zA-Z0-9_\[\]]+)\}(.+?)\{\/block\}/is", array($this, 'parse_template_callback_stripblock_12'), $template);
		$template = preg_replace("/\<\?(\s{1})/is", "<?php\\1", $template);
		$template = preg_replace("/\<\?\=(.+?)\?\>/is", "<?php echo \\1;?>", $template);

        //写入缓存文件
        $this->makepath(DISCUZ_ROOT.$cachefile);
		if(!@$fp = fopen(DISCUZ_ROOT.$cachefile, 'w')) {
			$this->error('directory_notfound', dirname(DISCUZ_ROOT.$cachefile));
		}

		flock($fp, 2);
		fwrite($fp, $template);
		fclose($fp);
	}

	function parse_template_callback_loadsubtemplate_2($matches) {
		return $this->loadsubtemplate($matches[2]);
	}

    function parse_template_callback_csstags_1($matches) {
        return $this->addcsslink($matches[1]);
	}

    function parse_template_callback_jstags_1($matches) {
        return $this->addjslink($matches[1]);
	}

    function parse_template_callback_languagevar_1($matches) {
		return $this->languagevar($matches[1]);
	}

	function parse_template_callback_evaltags_2($matches) {
		return $this->evaltags($matches[2]);
	}

	function parse_template_callback_evaltags_1($matches) {
		return $this->evaltags($matches[1]);
	}

	function parse_template_callback_addquote_1($matches) {
		return $this->addquote('<?='.$matches[1].'?>');
	}

	function parse_template_callback_stripvtags_template1($matches) {
		return $this->stripvtags('<? include template(\''.$matches[1].'\'); ?>');
	}

	function parse_template_callback_stripvtags_echo1($matches) {
		return $this->stripvtags('<? echo '.$matches[1].'; ?>');
	}

	function parse_template_callback_stripvtags_if123($matches) {
		return $this->stripvtags($matches[1].'<? if('.$matches[2].') { ?>'.$matches[3]);
	}

	function parse_template_callback_stripvtags_elseif123($matches) {
		return $this->stripvtags($matches[1].'<? } elseif('.$matches[2].') { ?>'.$matches[3]);
	}

	function parse_template_callback_stripvtags_loop12($matches) {
		return $this->stripvtags('<? if(is_array('.$matches[1].')) foreach('.$matches[1].' as '.$matches[2].') { ?>');
	}

	function parse_template_callback_stripvtags_loop123($matches) {
		return $this->stripvtags('<? if(is_array('.$matches[1].')) foreach('.$matches[1].' as '.$matches[2].' => '.$matches[3].') { ?>');
	}

	function parse_template_callback_transamp_0($matches) {
		return $this->transamp($matches[0]);
	}

	function parse_template_callback_stripblock_12($matches) {
		return $this->stripblock($matches[1], $matches[2]);
	}

    function languagevar($var) {
    	if (!isset($this->language['inner'])) {
			$this->language['inner'] = lang('template');
            $this->depfiles[] = langfile('template');
			$pieces = explode('/', $this->file);
            $path = '';
            for($i=0; $i<count($pieces)-1; $i++)
            {
                $path .= '/'.$pieces[$i];
                $this->depfiles[] = langfile($path.'/template');
                foreach(lang($path.'/template') as $k => $v) {
                    $this->language['inner'][$k] = $v;
                }
            }
		}
		if(isset($this->language['inner'][$var])) {
			return $this->language['inner'][$var];
		} else {
			return '!'.$var.'!';
		}
	}

	function evaltags($php) {
		$i = count($this->replacecode['search']);
		$this->replacecode['search'][$i] = $search = "<!--EVAL_TAG_$i-->";
		$this->replacecode['replace'][$i] = "<? $php?>";
		return $search;
	}

	function loadsubtemplate($file) {
		$tplfile = template($file, 1);
		$filename = DISCUZ_ROOT.$tplfile;
		if(($content = @implode('', file($filename))) || ($content = $this->getphptemplate(@implode('', file(substr($filename, 0, -4).'.php'))))) {
			$this->depfiles[] = $tplfile;
			return $content;
		} else {
			return '<!-- '.$file.' -->';
		}
	}

    function addcsslink($var) {
        $cssfile = CSSDIR.$var.'.css';
        $this->depfiles[] = $cssfile;
        $version = @filemtime(DISCUZ_ROOT.$cssfile);
        return  "<link rel=\"stylesheet\" href=\"$cssfile?v=$version\">";
    }

    function addjslink($var) {
        $jsfile = JSDIR.$var.'.js';
        $this->depfiles[] = $jsfile;
        $version = @filemtime(DISCUZ_ROOT.$jsfile);
        return  "<script type=\"text/javascript\" src=\"$jsfile?v=$version\"></script>";
    }

	function getphptemplate($content) {
		$pos = strpos($content, "\n");
		return $pos !== false ? substr($content, $pos + 1) : $content;
	}

	function transamp($str) {
		$str = str_replace('&', '&amp;', $str);
		$str = str_replace('&amp;amp;', '&amp;', $str);
		return $str;
	}

	function addquote($var) {
		return str_replace("\\\"", "\"", preg_replace("/\[([a-zA-Z0-9_\-\.\x7f-\xff]+)\]/s", "['\\1']", $var));
	}

	function stripvtags($expr, $statement = '') {
		$expr = str_replace('\\\"', '\"', preg_replace("/\<\?\=(\\\$.+?)\?\>/s", "\\1", $expr));
		$statement = str_replace('\\\"', '\"', $statement);
		return $expr.$statement;
	}



	function stripblock($var, $s) {
		$s = preg_replace("/<\?=\\\$(.+?)\?>/", "{\$\\1}", $s);
		preg_match_all("/<\?=(.+?)\?>/", $s, $constary);
		$constadd = '';
		$constary[1] = array_unique($constary[1]);
		foreach($constary[1] as $const) {
			$constadd .= '$__'.$const.' = '.$const.';';
		}
		$s = preg_replace("/<\?=(.+?)\?>/", "{\$__\\1}", $s);
		$s = str_replace('?>', "\n\$$var .= <<<EOF\n", $s);
		$s = str_replace('<?', "\nEOF;\n", $s);
		$s = str_replace("\nphp ", "\n", $s);
		return "<?\n$constadd\$$var = <<<EOF\n".$s."\nEOF;\n?>";
	}

	function error($message, $tplname) {
        throw new Exception($tplname.': '.$message);
	}

    //根据指定的路径创建不存在的文件夹
    function makepath($file)
    {
        $dir = dirname($file);
        if(!file_exists($dir)) {
            @mkdir($dir, 0777, true);
        }
        if(!file_exists($dir.'/index.html')) {
            @touch($dir.'/index.html');
            @chmod($dir.'/index.html', 0777);
        }
    }
}

?>