<?php

define('DISCUZ_ROOT', substr(dirname(__FILE__), 0, -15)); //网站根目录
define('TPLDIR', './template/'); //指定模板文件存放目录
define('CACHEDIR', './data/template/'); //指定缓存文件存放目录
define('CSSDIR', './static/css/'); //指定风格文件存放目录
define('JSDIR', './static/js/'); //指定Javascript文件存放目录
define('LANGDIR', './source/language/'); //指定语言包文件存放目录

function strexists($string, $find) {
	return !(strpos($string, $find) === FALSE);
}

function langfile($file) {
    $path = dirname($file);
    $file = basename($file);
    return LANGDIR.($path == '.' ? '' : $path.'/').'lang_'.$file.'.php';
}

function lang($file) {
    $lang = array();
    @include DISCUZ_ROOT.langfile($file);
	return $lang;
}

function checktplrefresh($tplfile, $depfile, $timecompare, $cachefile, $file) {
    if(empty($timecompare) || @filemtime(DISCUZ_ROOT.$depfile) > $timecompare) {
        require_once DISCUZ_ROOT.'/source/class/class_template.php';
	    $template = new template();
		$template->parse_template($tplfile, $file, $cachefile);
		return TRUE;
	}
	return FALSE;
}

function template($file, $gettplfile = 0) {

    $tplfile = TPLDIR.$file.'.htm';//模板源文件，此处$tplfile变量的值可能是D:\discuz\template\default\demo.htm
    $cachefile = CACHEDIR.$file.'.tpl.php';//模板缓存文件，此处$cachefile变量的值可能是D:\discuz\data\template\default\demo.htm.tpl.php

	if($gettplfile) {
		return $tplfile;
	}
	checktplrefresh($tplfile, $tplfile, @filemtime(DISCUZ_ROOT.$cachefile), $cachefile, $file);
	return DISCUZ_ROOT.$cachefile;
}
?>